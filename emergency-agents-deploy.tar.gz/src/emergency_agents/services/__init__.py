"""服务层模块。"""

from .rescue_draft_service import RescueDraftService, RescueDraftRecord

__all__ = ["RescueDraftService", "RescueDraftRecord"]
