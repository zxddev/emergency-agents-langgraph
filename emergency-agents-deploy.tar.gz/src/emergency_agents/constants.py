from __future__ import annotations

from typing import Final

# 全局默认演示事件ID，AI在缺乏上下文时回退到该事件以维持链路
RESCUE_DEMO_INCIDENT_ID: Final[str] = "fef8469f-5f78-4dd4-8825-dbc915d1b630"

