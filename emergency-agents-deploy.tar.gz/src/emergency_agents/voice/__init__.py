# Copyright 2025 msq
from __future__ import annotations

"""Voice 子系统入口。"""


