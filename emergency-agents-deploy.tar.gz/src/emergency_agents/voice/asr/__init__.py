# Copyright 2025 msq
from __future__ import annotations

"""ASR 子模块。"""


